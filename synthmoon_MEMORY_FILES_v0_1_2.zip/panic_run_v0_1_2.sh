#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

echo "[1/4] uv sync"
uv sync >/dev/null

echo "[2/4] ensure kernels"
uv run python scripts/download_kernels.py

# optional datasets (won't error if scripts missing)
if [ -f scripts/download_lroc_wac_albedo_map.py ]; then
  echo "[3/4] (optional) LROC albedo map"
  uv run python scripts/download_lroc_wac_albedo_map.py || true
fi

if [ -f scripts/download_lola_ldem16_dem.py ]; then
  echo "[3/4] (optional) LOLA DEM"
  uv run python scripts/download_lola_ldem16_dem.py || true
fi

echo "[4/4] render"
PYTHONPATH=$PWD uv run python -m synthmoon.run_v0 --config scene.toml

echo "Done."
