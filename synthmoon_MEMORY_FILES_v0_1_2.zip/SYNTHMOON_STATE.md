# SYNTHMOON_STATE (copy/paste into a new chat)

Project: SynthMoon — synthetic lunar images illuminated by Sun + Earthlight.

Current status (v0.1.x):
- Output FITS is a multi-layer cube in PRIMARY (3D) with layers:
  SCALED, IFTOTAL, IF_SUN, IF_EARTH, RADTOT, RAD_SUN, RAD_EAR, ALBMOON, ELEV_M, SLOPDEG
- Pixel grid: 512×512, FOV ~1°.
- Floating point output (float32/float64 selectable), plus a SCALED layer mapped to 0..65535 (float).
- Earthlight:
  - Earth treated as extended disk; sampled over its apparent disk with N samples
  - Earth phase included (sunlit part only contributes)
  - Partial Earth visibility near lunar horizon implemented.
  - Optional toy land/ocean + simple clouds, or equirectangular albedo map.
- Moon albedo:
  - constant or LROC WAC global mosaic (16 px/deg) converted to float FITS map.
- Moon orography:
  - LOLA LDEM_16 DEM downloaded (PDS label+IMG), converted to float FITS (absolute radius).
  - DEM used by iteratively refining per-ray intersection radius.
  - DEM diagnostics saved: elevation (m) and slope (deg).
- Sun:
  - v0.1.2 adds **extended solar disk** (finite diameter) near the terminator/horizon:
    [sun]
    extended_disk = true
    disk_samples = 64
    radius_km = 695700.0

Key run command:
  PYTHONPATH=$PWD uv run python -m synthmoon.run_v0 --config scene.toml

Big-data policy:
- Do NOT commit DATA/LOLA_GDR/* or DEM FITS; ignore via .gitignore.
- LROC + derived FITS ideally should also be ignored; scripts regenerate them.

Next physics upgrades:
- Terrain cast shadows (DEM line-of-sight) for Sun and for each Earth sample (penumbra/horizon).
- Better BRDF (Hapke) and spectral bands/filters.
