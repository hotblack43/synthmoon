# README_PANIC_WHATNOW (SynthMoon)

If you feel lost, do exactly this:

## 0) Get to the project folder
```bash
cd ~/WORKSHOP/SYNTHMOON
```

## 1) Make sure dependencies are installed (uv will create/use .venv automatically)
```bash
uv sync
```

## 2) Make sure SPICE kernels exist
```bash
uv run python scripts/download_kernels.py
```

## 3) (Optional but typical) Download lunar albedo + DEM (big files; not meant for git)
```bash
uv run python scripts/download_lroc_wac_albedo_map.py
uv run python scripts/download_lola_ldem16_dem.py
```

## 4) Run the renderer (NO activation needed)
```bash
PYTHONPATH=$PWD uv run python -m synthmoon.run_v0 --config scene.toml
```

Output is written to whatever `paths.out_fits` says (usually `OUTPUT/synth_moon_v0.fits`).

---

# How to go back to a known-good version (git tags)

## Make a tag at a known-good state (do this when it works)
```bash
git tag -a v0.1.2 -m "working v0.1.2 (extended Sun disk)"
git push --tags
```

## Later: return to it
```bash
git fetch --tags
git checkout v0.1.2
```

To return to latest main:
```bash
git checkout main
git pull
```

(When you are on a tag, you are in a "detached HEAD" state — that is OK for running.
If you want to make new commits from there, create a branch: `git checkout -b myfix`.)

---

# The run command explained (why that PYTHONPATH thing exists)

- `uv run ...` runs Python inside the project's `.venv` without you having to activate anything.
- `-m synthmoon.run_v0` means "run the module synthmoon/run_v0.py".
- `PYTHONPATH=$PWD` ensures Python imports **your local synthmoon/ folder** even if the package
  isn’t formally installed.

So the safest always-works command is:
```bash
PYTHONPATH=$PWD uv run python -m synthmoon.run_v0 --config scene.toml
```

---

# Don’t accidentally commit big data

The LROC TIFF/FITS and LOLA DEM are big.
Prefer:
- keep them in `DATA/` but **ignore** them in `.gitignore`
- keep scripts that re-download/re-create them

If you already committed big files and GitHub complains, ask for help and we’ll clean it up safely.
