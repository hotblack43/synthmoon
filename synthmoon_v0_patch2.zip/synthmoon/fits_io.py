from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import numpy as np
from astropy.io import fits


@dataclass(frozen=True)
class ScaleU16Result:
    data_u16: np.ndarray
    vmin: float
    vmax: float


def scale_float_to_uint16_full_range(img: np.ndarray) -> ScaleU16Result:
    """
    Scale float image to uint16 display range [0, 65535].

    This produces a *display* image that always has:
      min(raw) = 0
      max(raw) = 65535 (unless image is constant or all-NaN)

    The exact float->u16 mapping is recorded via SCLMIN/SCLMAX header keywords.

    NOTE:
      - This is a display encoding. The recommended scientific data are kept in the FLOAT32 extension.
      - vmin/vmax are taken from finite pixels only.
    """
    img = np.asarray(img, dtype=np.float32)
    finite = np.isfinite(img)
    if not np.any(finite):
        data = np.zeros(img.shape, dtype=np.uint16)
        return ScaleU16Result(data, float("nan"), float("nan"))

    vmin = float(np.min(img[finite]))
    vmax = float(np.max(img[finite]))

    if vmax == vmin:
        data = np.zeros(img.shape, dtype=np.uint16)
        return ScaleU16Result(data, vmin, vmax)

    # Map vmin -> 0, vmax -> 65535
    scaled = (img - vmin) / (vmax - vmin)
    scaled = np.clip(scaled, 0.0, 1.0)
    data = np.round(scaled * 65535.0).astype(np.uint16)
    return ScaleU16Result(data, vmin, vmax)


def write_fits(
    out_path: str | Path,
    img_float: np.ndarray,
    header_cards: dict,
    store_uint16_display: bool = True,
    store_float_extension: bool = True,
) -> None:
    """
    Write FITS with:
      - Primary HDU: uint16 display image (0..65535), with SCLMIN/SCLMAX describing mapping
      - FLOAT32 extension: the true float image (recommended for analysis)

    This avoids negative-looking primary data while preserving full float precision.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    hdr = fits.Header()
    for k, (v, c) in header_cards.items():
        # Keep comments short to avoid astropy VerifyWarning about long cards.
        hdr[k] = (v, c)

    hdul = []

    if store_uint16_display:
        sc = scale_float_to_uint16_full_range(img_float)
        hdr["SCLMODE"] = ("F2U16", "Float->u16")
        hdr["SCLMIN"] = (sc.vmin, "Float min")
        hdr["SCLMAX"] = (sc.vmax, "Float max")

        # Astropy will write unsigned 16-bit using the standard FITS convention (BITPIX=16 + BZERO=32768).
        prim = fits.PrimaryHDU(data=sc.data_u16, header=hdr)
    else:
        prim = fits.PrimaryHDU(data=np.asarray(img_float, dtype=np.float32), header=hdr)

    hdul.append(prim)

    if store_float_extension:
        h = fits.ImageHDU(data=np.asarray(img_float, dtype=np.float32), name="FLOAT32")
        hdul.append(h)

    fits.HDUList(hdul).writeto(out_path, overwrite=True)
