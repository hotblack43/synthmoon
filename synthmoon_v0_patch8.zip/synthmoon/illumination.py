from __future__ import annotations

import numpy as np
from dataclasses import dataclass

from .spice_tools import inv_solar_irradiance_scale
from .intersect import ray_sphere_intersect


def _normalize(v: np.ndarray, eps: float = 1e-15) -> np.ndarray:
    n = np.linalg.norm(v, axis=-1, keepdims=True)
    n = np.maximum(n, eps)
    return v / n


@dataclass(frozen=True)
class EarthDiskSampler:
    """
    Deterministic quasi-random samples over a spherical cap (Earth disk) using
    low-discrepancy sequences in (u,v).

    For a given angular radius alpha, we sample:
      cos(theta) = 1 - u*(1 - cos(alpha))
      phi = 2*pi*v
    Weight per sample = Omega / N, where Omega = 2*pi*(1 - cos(alpha))
    """
    n_samples: int
    u: np.ndarray  # (N,)
    v: np.ndarray  # (N,)

    @staticmethod
    def create(n_samples: int) -> "EarthDiskSampler":
        i = np.arange(n_samples, dtype=float)
        u = (i * 0.6180339887498949) % 1.0
        v = (i * 0.7548776662466927) % 1.0
        return EarthDiskSampler(n_samples=n_samples, u=u, v=v)

    def directions(self, e_dir: np.ndarray, alpha: float) -> tuple[np.ndarray, float]:
        """
        Build direction vectors (N,3) for the cap around e_dir with half-angle alpha (radians).
        Returns (omega, w) where w is per-sample solid-angle weight.
        """
        e = e_dir / np.linalg.norm(e_dir)
        tmp = np.array([0.0, 0.0, 1.0])
        if abs(np.dot(tmp, e)) > 0.9:
            tmp = np.array([0.0, 1.0, 0.0])
        u_hat = np.cross(tmp, e)
        u_hat /= np.linalg.norm(u_hat)
        v_hat = np.cross(e, u_hat)

        cos_alpha = np.cos(alpha)
        cos_t = 1.0 - self.u * (1.0 - cos_alpha)
        sin_t = np.sqrt(np.maximum(0.0, 1.0 - cos_t * cos_t))
        phi = 2.0 * np.pi * self.v

        omega = (cos_t[:, None] * e[None, :]) + (
            sin_t[:, None] * (np.cos(phi)[:, None] * u_hat[None, :] + np.sin(phi)[:, None] * v_hat[None, :])
        )
        omega = _normalize(omega)

        Omega = 2.0 * np.pi * (1.0 - cos_alpha)
        w = Omega / float(self.n_samples)
        return omega, float(w)


def lambert_sun_if(hit_points: np.ndarray, normals: np.ndarray, sun_pos: np.ndarray, moon_albedo: float) -> np.ndarray:
    """
    Direct solar contribution in I/F_moon units (normalised by solar irradiance at the lunar point).
    For Lambert, I/F = A_moon * mu0.
    """
    s_dir = _normalize(sun_pos[None, :] - hit_points)
    mu0 = np.maximum(0.0, np.sum(normals * s_dir, axis=1))
    return moon_albedo * mu0


def earthlight_if_tilecached(
    hit_points: np.ndarray,
    normals: np.ndarray,
    moon_center: np.ndarray,
    sun_pos: np.ndarray,
    earth_pos: np.ndarray,
    moon_albedo: float,
    earth_albedo: float,
    earth_radius_km: float,
    n_samples: int,
    tile_px: int,
    ij: np.ndarray,
    nx: int,
    ny: int,
) -> np.ndarray:
    """
    Compute earthlight contribution to I/F_moon in a tile-cached way.

    IMPORTANT (patch8): handle partial Earth visibility near the lunar horizon.

    Near the horizon, the Earth centre can be below the horizon while *part* of the Earth disk is still visible.
    Using a simple Earth-centre-above-horizon test (dot(radial, e_dir) > 0) incorrectly makes the contribution
    drop too fast and can create ring-like artefacts.

    We fix this by:
      1) Computing Earth angular radius alpha at the tile representative point.
      2) Declaring "some of Earth disk visible" when dot(radial, e_dir) > -sin(alpha).
         (Earth centre may be slightly below horizon; top limb still visible.)
      3) Applying an explicit per-direction horizon mask using the *radial* horizon plane:
           keep only sampled directions omega with dot(radial, omega) > 0.

    This also keeps behaviour sensible once lunar normals come from a DEM (slopes), because visibility is geometric
    (radial horizon) rather than tied to the BRDF normal.
    """
    out = np.zeros(hit_points.shape[0], dtype=np.float32)

    sampler = EarthDiskSampler.create(n_samples)

    # Solar irradiance scale at each lunar point for I/F normalisation (F(1 AU)=1)
    F_moon = np.array([inv_solar_irradiance_scale(hit_points[k], sun_pos) for k in range(hit_points.shape[0])], dtype=float)

    ti = ij[:, 0] // tile_px
    tj = ij[:, 1] // tile_px
    tile_id = ti + (nx // tile_px + 1) * tj
    unique_tiles = np.unique(tile_id)

    for tid in unique_tiles:
        idx_all = np.where(tile_id == tid)[0]
        if idx_all.size == 0:
            continue

        # Representative point for this tile (used for Earth disk sampling directions)
        k0 = int(idx_all[0])
        x0 = hit_points[k0]

        # Earth angular radius at representative point
        d_em0 = float(np.linalg.norm(earth_pos - x0))
        alpha0 = np.arcsin(np.clip(earth_radius_km / d_em0, 0.0, 1.0))
        sin_alpha0 = float(np.sin(alpha0))

        # Per-pixel "any of Earth disk visible?" using dot(radial, e_dir) > -sin(alpha)
        radial = _normalize(hit_points[idx_all] - moon_center[None, :])                 # (P,3)
        e_dir = _normalize(earth_pos[None, :] - hit_points[idx_all])                   # (P,3)
        dot0 = np.einsum("ij,ij->i", radial, e_dir)                                    # (P,)

        vis_any = dot0 > (-sin_alpha0)
        if not np.any(vis_any):
            continue

        idx = idx_all[vis_any]

        # Directions that fill the Earth disk around Earth-centre direction at x0
        e_dir0 = earth_pos - x0
        e_dir0 /= np.linalg.norm(e_dir0)
        omega, w = sampler.directions(e_dir0, alpha0)  # (S,3), per-sample solid-angle weight

        # Intersect sampled directions with Earth sphere to get Earth surface points
        origins = np.repeat(x0[None, :], omega.shape[0], axis=0)
        hitE, tE = ray_sphere_intersect(origins, omega, earth_pos, earth_radius_km)
        if not np.any(hitE):
            continue

        pE = origins[hitE] + tE[hitE, None] * omega[hitE]
        nE = _normalize(pE - earth_pos[None, :])

        # Sun illumination at Earth patch (Earth phase lives here)
        sE = _normalize(sun_pos[None, :] - pE)
        mu0E = np.maximum(0.0, np.sum(nE * sE, axis=1))

        # Patch must face the Moon: direction from patch to Moon is -omega
        omega_hit = omega[hitE]
        muE = np.maximum(0.0, np.sum(nE * (-omega_hit), axis=1))

        # Solar irradiance at Earth patch (F(1 AU)=1)
        F_E = np.array([inv_solar_irradiance_scale(pE[i], sun_pos) for i in range(pE.shape[0])], dtype=float)

        # Earth radiance toward Moon along omega (Lambert): L = (A/π) * F * mu0
        L = (earth_albedo / np.pi) * F_E * mu0E
        L *= (muE > 0).astype(float)

        omega_use = omega_hit  # (M,3)
        L_use = L              # (M,)

        # BRDF incidence on Moon from each sampled direction
        dot_inc = normals[idx] @ omega_use.T                 # (P,M)
        cos_m = np.maximum(0.0, dot_inc)

        # Explicit geometric horizon mask (partial-disk support):
        # Keep only directions above radial horizon plane: dot(radial, omega) > 0
        radial_idx = _normalize(hit_points[idx] - moon_center[None, :])                # (P,3)
        dot_h = radial_idx @ omega_use.T                                               # (P,M)
        cos_m = np.where(dot_h > 0.0, cos_m, 0.0)

        # Irradiance at Moon from Earth radiance samples
        E = (cos_m * (L_use[None, :])).sum(axis=1) * w

        # Convert to I/F_moon and store
        out[idx] = (moon_albedo * (E / F_moon[idx])).astype(np.float32)

    return out
